RAMANI GROUPS - GITHUB TEMPORARY VERSION

This package is designed for temporary GitHub Pages hosting.

Important:
- GitHub Pages cannot run PHP, so this version uses browser localStorage.
- Leads will be visible in the dashboard only in the same browser/device where the form was submitted.
- For real multi-user showroom access, upload the PHP version to GoDaddy/Linux hosting or use Firebase/Supabase.

Dashboard location:
- lead-sheets/brand-dashboard-links.html
- lead-sheets/leads-dashboard.html
- lead-sheets/volkswagen-leads-dashboard.html
- lead-sheets/mahindra-leads-dashboard.html
- lead-sheets/mg-leads-dashboard.html
- lead-sheets/kia-leads-dashboard.html

Default logins:
Super Admin: superadmin / Creator@2026
Main Admin: ramaniadmin / Ramani@2026
Volkswagen: vwmanager / VW@2026
Mahindra: mahindramanager / Mahindra@2026
MG: mgmanager / MG@2026
Kia: kiamanager / Kia@2026
