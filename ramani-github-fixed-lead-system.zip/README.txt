RAMANI GROUPS - COMPLETE LEAD SYSTEM

Upload all files in this folder to your GoDaddy hosting public folder.

Main files:
- api.php: stores leads and users in /data JSON files.
- ramani-leads.js: sends website form leads to api.php.
- leads-dashboard.html: main dashboard for all website leads.
- volkswagen-leads-dashboard.html
- mahindra-leads-dashboard.html
- mg-leads-dashboard.html
- kia-leads-dashboard.html
- brand-dashboard-links.html

Default logins:
1) Super Admin / Creator
   Login ID: superadmin
   Password: Creator@2026

2) Main Admin
   Login ID: ramaniadmin
   Password: Ramani@2026

3) Volkswagen Admin
   Login ID: vwmanager
   Password: VW@2026

4) Mahindra Admin
   Login ID: mahindramanager
   Password: Mahindra@2026

5) MG Admin
   Login ID: mgmanager
   Password: MG@2026

6) Kia Admin
   Login ID: kiamanager
   Password: Kia@2026

Notes:
- The dashboards use the same Ramani Groups theme, without website header/footer.
- Google Sheet scripts were removed and replaced with GoDaddy PHP JSON storage.
- Main dashboard receives all leads: test drive, service appointment, contact, career, newsletter and homepage popup.
- Brand dashboards show only that brand's leads.
- Super admin can access all dashboards and manage users.
- Brand admins can add/edit users for their own brand.
- Every password section has an eye icon.


UPDATED FOLDER STRUCTURE:
The 5 lead sheets are now inside the /lead-sheets/ folder:
- lead-sheets/leads-dashboard.html
- lead-sheets/volkswagen-leads-dashboard.html
- lead-sheets/mahindra-leads-dashboard.html
- lead-sheets/mg-leads-dashboard.html
- lead-sheets/kia-leads-dashboard.html

The main website index.html remains in the root folder.
Use lead-sheets/brand-dashboard-links.html to open all dashboard links.
A shortcut file lead-sheets.html is also included in the root.
